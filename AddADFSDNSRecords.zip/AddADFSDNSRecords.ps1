﻿configuration AddADFSDNSRecords 
{ 
   #v1.0
   param
    (
        [string[]]$NodeName="localhost",

        [Parameter(Mandatory)]
        [string]$ADFSServer01IP,

        [Parameter(Mandatory)]
        [string]$ADFSServer02IP,
        
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Node $NodeName
    {


        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }

         
        Script addDNSRecords  #Add ADFS Server DNS Records
        {
            GetScript = { @{Result = {Get-DNSServerResourceRecord -Zone nivlab.thecloudguy.info -Name fs}}}
            SetScript = {
            #add the following records to DNS

            Add-DNSServerResourceRecord -Zonename nivlab.thecloudguy.info -ComputerName DC01 -IPv4Address $using:ADFSServer01IP -Name fs -A
            Add-DNSServerResourceRecord -Zonename nivlab.thecloudguy.info -ComputerName DC01 -IPv4Address $using:ADFSServer02IP -Name fs -A
            
            Get-DNSServerResourceRecord -Zone nivlab.thecloudguy.info -Name fs > "C:\Packages\fs.nivlab.thecloudguy.info_dns.txt"
                     
            }

            #check if the ADFS DNS Records have been output to file. If yes then nothing to do
            TestScript = { Test-Path "C:\Packages\fs.nivlab.thecloudguy.info_dns.txt" }
        }
    }
} 
