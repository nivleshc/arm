﻿configuration CreateFirstADFSServer 
{ 
   #v1.1
   param
    (
        [string[]]$NodeName="localhost",

        [Parameter(Mandatory)]
        [string]$MachineName,

        [Parameter(Mandatory)]
        [string]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    #Import the required DSC Resources
    Import-DscResource -Module xComputerManagement, xActiveDirectory, xPendingReboot
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$ServiceCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\svc_adfs)", (ConvertTo-SecureString "P@sssw0rd01" -AsPlainText -force))

    Node $NodeName
    {


        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }

         
        xComputer JoinDomain
        {
            Name          = $MachineName 
            DomainName    = $DomainName
            Credential    = $DomainCreds  # Credential to join to domain
        }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]JoinDomain"
        }

        WindowsFeature installADFS  #install ADFS
        {
            Ensure = "Present"
            Name   = "ADFS-Federation"
            DependsOn = "[xPendingReboot]Reboot1"
        }

        Script configureADFS  #Configure ADFS
        {
            SetScript = {
            #install the self-signed certificate
            Import-PfxCertificate -Exportable -Password (ConvertTo-SecureString "P@ssw0rd01" -AsPlainText -Force) `
            -CertStoreLocation cert:\localmachine\my -FilePath "C:\Program Files\WindowsPowerShell\Modules\Certificates\fs.nivlab.thecloudguy.info_full.pfx"
            
            #get the thumbprint of the certificate
            $cert = Get-ChildItem -Path Cert:\LocalMachine\my | ?{$_.Subject -eq "CN=fs.nivlab.thecloudguy.info, OU=Free SSL, OU=Domain Control Validated"} 
            
            #Configure ADFS
            Install-AdfsFarm -CertificateThumbprint $cert.thumbprint -Credential $DomainCreds `
            -FederationServiceName fs.nivlab.thecloudguy.info -FederationServiceDisplayName "Nivlab Federation Service" `
            -OverwriteConfiguration -ServiceAccountCredential $ServiceCreds
            
            #Copy certificate to C:\packages to signal that all ended successfully
            Copy-Item -Path  "C:\Program Files\WindowsPowerShell\Modules\Certificates\fs.nivlab.thecloudguy.info_full.pfx" -Destination "C:\Packages\"         
            }

            #check if the self-signed certificate exists. If not then this ADFS has not been configured
            Test-Script = { Test-Path "C:\Packages\fs.nivlab.thecloudguy.info_full.pfx"}
            DependsOn = "[WindowsFeature]installADFS"
        }
    }
} 
