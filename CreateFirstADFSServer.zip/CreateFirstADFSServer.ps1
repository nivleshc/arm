﻿configuration CreateFirstADFSServer 
{ 
   #v1.12
   param
    (
        [string[]]$NodeName="localhost",

        [Parameter(Mandatory)]
        [string]$MachineName,

        [Parameter(Mandatory)]
        [string]$DomainName,
        
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    #Import the required DSC Resources
    Import-DscResource -Module xComputerManagement, xActiveDirectory, xPendingReboot
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node $NodeName
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }

         
        xComputer JoinDomain
        {
            Name          = $MachineName 
            DomainName    = $DomainName
            Credential    = $DomainCreds  # Credential to join to domain
        }

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xComputer]JoinDomain"
        }

        WindowsFeature installADFS  #install ADFS
        {
            Ensure = "Present"
            Name   = "ADFS-Federation"
            DependsOn = "[xPendingReboot]Reboot1"
        }

        Script configureADFS  #Configure ADFS
        {
            GetScript = { @{Result = {"Done"}}}
            SetScript = {
                $env:PSModulePath = [System.Environment]::GetEnvironmentVariable("PSModulePath","Machine")

                $localpath = "C:\Program Files\WindowsPowerShell\Modules\Certificates\"
                $Key = (3,4,2,3,56,34,254,222,1,1,2,23,42,54,33,233,1,34,2,7,6,5,35,43)

                #get the admin and adfs passwords first
                $adminpassword = Convertto-SecureString -String (Get-Content -Path $($localpath+"adminpass.key")) -key $key
                
                $adfspassword = Convertto-SecureString -String (Get-Content -Path $($localpath+"adfspass.key")) -key $key
                
                $DomainAdminCreds = New-Object System.Management.Automation.PSCredential($($using:DomainName+"\adadmin"), $adminpassword)

                $AdfsSvcCreds = New-Object System.Management.Automation.PSCredential($($using:DomainName+"\svc-adfs"), $adfspassword)
            
                Import-PfxCertificate -Exportable -Password $adminpassword -CertStoreLocation cert:\localmachine\my -FilePath $($localpath+"fs.nivlab.thecloudguy.info_full.pfx")
            
                #get thumbprint of certificate
                $cert = Get-ChildItem -Path Cert:\LocalMachine\my | ?{$_.Subject -eq "CN=fs.nivlab.thecloudguy.info, OU=Free SSL, OU=Domain Control Validated"} 


                #Configure ADFS
                Install-AdfsFarm -CertificateThumbprint $cert.thumbprint -Credential $DomainAdminCreds `
                -FederationServiceName fs.nivlab.thecloudguy.info -FederationServiceDisplayName "Nivlab Federation Service" `
                 -ServiceAccountCredential $AdfsSvcCreds -OverwriteConfiguration
            
                #Copy certificate to C:\packages to signal that all ended successfully
                Copy-Item -Path  $($localpath+"fs.nivlab.thecloudguy.info_full.pfx") -Destination "C:\Packages\"         
                }

                #check if the self-signed certificate exists. If not then this ADFS has not been configured
                TestScript = { Test-Path "C:\Packages\fs.nivlab.thecloudguy.info_full.pfx" }
                DependsOn = "[WindowsFeature]installADFS"
                PsDscRunAsCredential =  $DomainAdminCreds
        }
    }
}