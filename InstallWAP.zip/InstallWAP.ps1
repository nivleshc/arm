﻿configuration InstallWAP 
{ 
   <# Version = v0.1
   Description: This DSC will install WAP role
   Change Record
   Date          Author               Comments
   01/09/16      Niv                  Created version of this script off previous script
   #>

   param
    (
        [string[]]$NodeName="localhost"
    )

    Node $NodeName
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }


        WindowsFeature installADFS  #install WAP Role
        {
            Ensure = "Present"
            Name   = "Web-Application-Proxy"
        }
    }
}