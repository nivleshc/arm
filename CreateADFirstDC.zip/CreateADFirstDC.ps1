﻿configuration CreateADFirstDC 
{ 
   #v1.2
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [string]$ADFSServer01IP,

        [Parameter(Mandatory)]
        [string]$ADFSServer02IP,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        } 

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = 'Ethernet'
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature RSAT
        {
            Ensure = "Present"
            Name = "RSAT"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
        }  

        xADDomain FirstDS 
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "C:\NTDS"
            LogPath = "C:\NTDS"
            SysvolPath = "C:\SYSVOL"
            DependsOn = "[WindowsFeature]ADDSInstall","[xDnsServerAddress]DnsServerAddress"
        }

        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential = $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = "[xADDomain]FirstDS"
        } 

        xADUser FirstUser 
        { 
            DomainName = $DomainName 
            DomainAdministratorCredential = $DomainCreds 
            UserName = "svc-adfs" 
            Password = $DomainCreds 
            Ensure = "Present" 
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        } 

        xPendingReboot Reboot1
        { 
            Name = "RebootServer"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

         Script addDNSRecords  #Add ADFS Server DNS Records
        {
            GetScript = { @{Result = {Get-DNSServerResourceRecord -Zone nivlab.thecloudguy.info -Name fs}}}
            SetScript = {
            #add the following records to DNS

            Add-DNSServerResourceRecord -Zonename nivlab.thecloudguy.info -ComputerName DC01 -IPv4Address $using:ADFSServer01IP -Name fs -A
            Add-DNSServerResourceRecord -Zonename nivlab.thecloudguy.info -ComputerName DC01 -IPv4Address $using:ADFSServer02IP -Name fs -A
            
            Get-DNSServerResourceRecord -Zone nivlab.thecloudguy.info -Name fs > "C:\Packages\fs.nivlab.thecloudguy.info_dns.txt"
                     
            }

            #check if the ADFS DNS Records have been output to file. If yes then nothing to do
            TestScript = { Test-Path "C:\Packages\fs.nivlab.thecloudguy.info_dns.txt" }
            DependsOn = "[xADUser]FirstUser"
        }

   }
} 